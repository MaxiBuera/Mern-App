 #include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "parser.h"
#include "libro.h"
#include "input.h"



void parser_LoadFromText(LinkedList *list, char* path)
{
    FILE *pFile;
    char id[4096];
    char titulo[4096];
    char autor[4096];
    char precio[4096];
    char editorialId[4096];

    int quantityRead;
    pFile = fopen(path,"r");
    if(pFile != NULL)
    {

        fscanf(pFile,"%[^,],%[^,]%[^,],%[^,],%[^\n]",id,titulo,autor,precio,editorialId);
        while(!feof(pFile))
        {
            quantityRead = fscanf(pFile,"%[^,],%[^,]%[^,],%[^,],%[^\n]",id,titulo,autor,precio,editorialId);

            if(quantityRead == 0)
            {
                break;
            }
            eLibro *nuevoLibro = libro_newParametros(id,titulo,autor,precio,editorialId);
            if(ll_add(list,nuevoLibro))
            {
                printf("\nError");
                continue;
            }
        }
        if(fclose(pFile))
        {
            printf("\nERROR AL CERRAR EL ARCHIVO");
        }
    }
    else
        printf("\nError al abrir el archivo");
}



void parser_SaveFromText(LinkedList *list, char* path)
{
    FILE *pFile;
    int len = ll_len(list);
    int i;
    int quantityWrite;
    pFile = fopen(path,"w");
    if(pFile != NULL)
    {
        fprintf(pFile,"ID,Titulo,Autor,Precio,EditorialId\n");
        for(i=0;i<len;i++)
        {
            eLibro* libro = ll_get(list,i);
            quantityWrite = fprintf(pFile,"%d,%s,%s,%d,%s\n",
                                    libro->id,
                                    libro->titulo,
                                    libro->autor,
                                    libro->precio,
                                    libro->editorialId);
            if(quantityWrite == 0)
            {
                break;
            }
        }
        if(fclose(pFile))
        {
            printf("\nERROR AL CERRAR EL ARCHIVO");
        }
    }
    else
        printf("\nError al abrir el archivo");
}


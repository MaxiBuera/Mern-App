#ifndef libro_H_INCLUDED
#define libro_H_INCLUDED
typedef struct
{
    int id;
    char titulo[200];
    char autor[200];
    int precio;
    char editorialId[200];
    float descuento;
}eLibro;

#endif // libro_H_INCLUDED
eLibro* libro_newParametros(char* idStr,char* tituloStr,char* autorStr,char* precioStr,char* editorialIdStr);
//eLibro* libro_newParametros2(char* titulo,char* precio,int tiempo);
/*eLibro* libro_newParametros3(int id,char* titulo,int horasTrabajadas,int sueldo);
eLibro* libro_newParametros4(int id,char* titulo,int horasTrabajadas,int sueldo);*/
eLibro* libro_new();
void libro_delete(eLibro* this);

int libro_setId(eLibro* this,int id);
int libro_getId(eLibro* this,int* id);

char libro_setTitulo(eLibro* this,char* titulo);
char libro_getTitulo(eLibro* this,char* titulo);

char libro_setAutor(eLibro* this,char* autor);
char libro_getAutor(eLibro* this,char* autor);

int libro_setPrecio(eLibro* this,int precio);
int libro_getPrecio(eLibro* this,int* precio);

char libro_setEditorialId(eLibro* this,char* editorialId);
char libro_getEditorialId(eLibro* this,char* editorialId);

float libro_setDescuento(eLibro* this,float descuento);
float libro_getDescuento(eLibro* this,float* descuento);
/*
int libro_velocidadPromedio(void* auxBicicleta);


*/
int libro_descuentoPLANETA(void* nuevoLibro);
int libro_descuentoSIGLOXXI(void* nuevoLibro);
int libro_descuentoPEARSON(void* nuevoLibro);
int libro_descuentoMINOTAURO(void* nuevoLibro);
int libro_descuentoSALAMANDRA(void* nuevoLibro);
int libro_descuentoPENGUINBOOKS(void* nuevoLibro);



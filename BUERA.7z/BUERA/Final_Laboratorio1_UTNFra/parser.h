void parser_LoadFromText(LinkedList *list, char* path);
void parser_SaveFromText(LinkedList *list, char* path);

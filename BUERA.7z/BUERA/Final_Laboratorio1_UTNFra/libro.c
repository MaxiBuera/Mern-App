#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "input.h"
#include "LinkedList.h"
#include "libro.h"
#include "parser.h"
#include "informes.h"


static int proximoId();

eLibro* libro_newParametros(char* idStr,char* tituloStr,char* autorStr,char* precioStr,char* editorialIdStr)
{
    eLibro* this;
    this = libro_new();

    char id; //si el id viene del archivo
    char titulo[200];
    char autor[200];
    int precio;
    char editorialId[200];

    id = atoi(idStr);
    strcpy(titulo,tituloStr);
    strcpy(autor,autorStr);
    precio = atoi(precioStr);
    strcpy(autor,editorialIdStr);

    //libro_setId(this,proximoId());
    libro_setId(this,id);
    libro_setTitulo(this,titulo);
    libro_setAutor(this,autor);
    libro_setPrecio(this,precio);
    libro_setEditorialId(this,editorialId);

    return this;
}
/*
eLibro* libro_newParametros2(char* titulo,char* autor,int precio){

    eLibro* this;
    this = libro_new();

    if(     !libro_setId(this, proximoId())
       &&   !libro_settitulo(this, titulo)
       &&   !libro_setautor(this, autor)
       &&   !libro_setprecio(this,precio))
    {
         return this;
    }
    libro_delete(this);
    return NULL;
}

eLibro* libro_newParametros3(int id,char* titulo,int horasTrabajadas,int sueldo){

    eLibro* this;
    this = libro_new();

    if(     !libro_setId(this, id)
       &&   !libro_settitulo(this, titulo)
       &&   !libro_setHorasTrabajadas(this, horasTrabajadas)
       &&   !libro_setSueldo(this,sueldo))
    {
         return this;
    }
    libro_delete(this);
    return NULL;
}

eLibro* libro_newParametros4(int id,char* titulo,int horasTrabajadas,int sueldo){

    eLibro* this;
    this = libro_new();

    if(     !libro_setId(this, proximoId())
       &&   !libro_settitulo(this, titulo)
       &&   !libro_setHorasTrabajadas(this, horasTrabajadas)
       &&   !libro_setSueldo(this,sueldo))
    {
         return this;
    }
    libro_delete(this);
    return NULL;
}*/

eLibro* libro_new()
{
    return malloc(sizeof(eLibro));
}

void libro_delete(eLibro* this)
{
    free(this);
}


int  libro_setId(eLibro* this, int id)
{
    int retorno = -1;
    if(this != NULL && id >= 0)
    {

        this->id = id;
        retorno = 0;
    }
    return retorno;
}

int libro_getId(eLibro* this, int* id)
{
    int retorno = -1;
    if(this != NULL && id != NULL)
    {

        *id = this->id;
         retorno = 0;
    }
    return retorno;
}


char  libro_setTitulo(eLibro* this, char* titulo)
{
    int retorno = -1;
    if(this != NULL && titulo != NULL)
    {

        strcpy(this->titulo,titulo);
        retorno = 0;
    }
    return retorno;
}


char libro_getTitulo(eLibro* this, char* titulo)
{
    int retorno = -1;
    if(this != NULL && titulo != NULL)
    {

        strcpy(titulo,this->titulo);
        retorno = 0;
    }
    return retorno;

}



char  libro_setAutor(eLibro* this, char* autor)
{
    int retorno = -1;
    if(this != NULL && autor != NULL)
    {

        strcpy(this->autor,autor);
        retorno = 0;
    }
    return retorno;
}


char libro_getAutor(eLibro* this, char* autor)
{
    int retorno = -1;
    if(this != NULL && autor != NULL)
    {

        strcpy(autor,this->autor);
        retorno = 0;
    }
    return retorno;

}


int libro_setPrecio(eLibro* this,int precio)
{
    int retorno = -1;
    if(this != NULL && precio >= 0)
    {
        this->precio=precio;
        retorno = 0;
    }
    return retorno;
}

int libro_getPrecio(eLibro* this , int* precio )
{
    int retorno = -1;

    if( (this != NULL) && (precio != NULL) )
    {
        *precio = this->precio;
        retorno = 0;
    }

    return retorno;
}
//

char  libro_setEditorialId(eLibro* this, char* editorialId)
{
    int retorno = -1;
    if(this != NULL && editorialId != NULL)
    {

        strcpy(this->editorialId,editorialId);
        retorno = 0;
    }
    return retorno;
}


char libro_getEditorialId(eLibro* this, char* editorialId)
{
    int retorno = -1;
    if(this != NULL && editorialId != NULL)
    {

        strcpy(editorialId,this->editorialId);
        retorno = 0;
    }
    return retorno;

}


float libro_setDescuento(eLibro* this,float descuento)
{
    int retorno = -1;
    if(this != NULL && descuento >= 0)
    {
        this->descuento=descuento;
        retorno = 0;
    }
    return retorno;
}

float libro_getDescuento(eLibro* this , float* descuento )
{
    int retorno = -1;

    if( (this != NULL) && (descuento != NULL) )
    {
        *descuento = this->descuento;
        retorno = 0;
    }

    return retorno;
}


static int proximoId()
{
    static int ultimoId = 0;
    ultimoId++;
    return ultimoId;
}


int libro_descuento(void* auxLibro){

    int retorno = -1;

    if(auxLibro != NULL){
/*
        int precio;
        float precioHora;
        float t;
        float velocidadPromedio;
        auxLibro = (eLibro*)auxBicicleta;

        libro_getPrecio(auxLibro, &precio);

        t = (float)precio;

        precioHora = t*0.01666666666;

        velocidadPromedio = 10/precioHora;
        libro_setVelocidadPromedio(auxLibro,velocidadPromedio);

*/
        retorno = 0;
    }
    return retorno;
}

int libro_descuentoPLANETA(void* nuevoLibro)
{
    int retorno = 0;

    if( strcmp("PLANETA",((eLibro*)nuevoLibro)->autor) == 0 )
    {
        retorno = 1;
    }
    return retorno;
}

int libro_descuentoSIGLOXXI(void* nuevoLibro)
{
    int retorno = 0;

    if( strcmp("SIGLO XXI EDITORES",((eLibro*)nuevoLibro)->autor) == 0 )
    {
        retorno = 1;
    }
    return retorno;
}

int libro_descuentoPEARSON(void* nuevoLibro)
{
    int retorno = 0;

    if( strcmp("PEARSON",((eLibro*)nuevoLibro)->autor) == 0 )
    {
        retorno = 1;
    }
    return retorno;
}

int libro_descuentoMINOTAURO(void* nuevoLibro)
{
    int retorno = 0;

    if( strcmp("MINOTAURO",((eLibro*)nuevoLibro)->autor) == 0 )
    {
        retorno = 1;
    }
    return retorno;
}


int libro_descuentoSALAMANDRA(void* nuevoLibro)
{
    int retorno = 0;

    if( strcmp("SALAMANDRA",((eLibro*)nuevoLibro)->autor) == 0 )
    {
        retorno = 1;
    }
    return retorno;
}

int libro_descuentoPENGUINBOOKS(void* nuevoLibro)
{
    int retorno = 0;

    if( strcmp("PENGUIN BOOKS",((eLibro*)nuevoLibro)->autor) == 0 )
    {
        retorno = 1;
    }
    return retorno;
}

/*
int libro_sortByautor(void* aux1,void* aux2)
{
    int retorno = 0;

    if( (aux1 != NULL) && (aux2 != NULL) )
    {
        char autor1[128];
        char autor2[128];

        libro_getautor(aux1, autor1);
        libro_getautor(aux2, autor2);

        if(hours1 > hours2)
            retorno = 1;
        else
        {
            if(hours1 < hours2)
                retorno = -1;
        }
    }

    return retorno;
}*/


#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "input.h"
#include "LinkedList.h"
#include "libro.h"
#include "parser.h"



void libro_printHeader(void)
{
    printf("\n-------------------------------------------------------------------------------\n");
    printf("ID      TITULO        AUTOR       PRECIO       ID EDITORIAL");
    printf("\n-------------------------------------------------------------------------------\n");
}

void libro_printHeader2(void)
{
    printf("\n-------------------------------------------------------------------------------\n");
    printf("ID      NOMBRE        TIPO       TIEMPO       ID EDITORIAL          DESCUENTO");
    printf("\n-------------------------------------------------------------------------------\n");
}


void libro_imprimirLibro(eLibro* nuevoLibro,int flag)
{
    if(nuevoLibro != NULL)
    {
        int id, precio;
        char titulo[200], autor[200], editorialId[200];
        float descuento;

        libro_getId(nuevoLibro, &id);
        libro_getTitulo(nuevoLibro, titulo);
        libro_getAutor(nuevoLibro, autor);
        libro_getPrecio(nuevoLibro, &precio);
        libro_getEditorialId(nuevoLibro, editorialId);

        if(flag == 0){

            printf("%d %12s %12s %9d %10s\n", id, titulo, autor, precio,editorialId);
        }
        else{
            libro_getDescuento(nuevoLibro, &descuento);
            printf("%d %12s %12s %9d %10s %9f.2\n", id, titulo, autor, precio,editorialId,descuento);
        }

    }
}

void libro_imprimirListaLibros(LinkedList* list,int flag)
{
    if(list != NULL)
    {
        int i;
        eLibro* nuevoLibro;

        if(flag == 0 ){

            libro_printHeader();
            for(i=0; i<ll_len(list); i++)
            {
                nuevoLibro = ll_get(list, i);
                libro_imprimirLibro(nuevoLibro,flag);
            }
        }
        else{

            libro_printHeader2();
            for(i=0; i<ll_len(list); i++)
            {
                nuevoLibro = ll_get(list, i);
                libro_imprimirLibro(nuevoLibro,flag);
            }
        }

        libro_printHeader();
        for(i=0; i<ll_len(list); i++)
        {
            nuevoLibro = ll_get(list, i);
            libro_imprimirLibro(nuevoLibro,flag);
        }
    }
}


int menu_Principal(char* msj )
{
    int aux;
    printf(msj);
    fflush(stdin);
    scanf("%d", &aux);
    return aux;
}

void libro_imprimirLibro(eLibro* nuevoLibro, int flag);
void libro_imprimirListaLibros(LinkedList* list, int flag);

int menu_Principal(char* msj );

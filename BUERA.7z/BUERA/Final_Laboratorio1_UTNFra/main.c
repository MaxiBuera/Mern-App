#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "libro.h"
#include "input.h"
#include "parser.h"
#include "informes.h"


int main()
{
    LinkedList *list = ll_newLinkedList();

    //LinkedList* pArraySubList;
    //LinkedList* listaPorTipo;

    int opcion;
    //int opcion2;
    int flag=0;
    //char archivo[128];

    /*int validaNombreArchivo(char* archivo){

        if(!getStringLetras("Ingrese nombre del Archivo: ",archivo)){

            parser_LoadFromText(list,archivo);
        }
        return 0;
    }
    */

    do
    {
        opcion = menu_Principal("\n\n1.Cargar archivo"
                                "\n2.Ordenar Lista Por Autor"
                                "\n3.Mostrar Lista"
                                "\n4.Generar Archivo"
                                "\n5.SALIR\n"
                            "\nElegir opcion: ");

        switch(opcion)
        {
        case 1:
            //validaNombreArchivo(archivo);
            parser_LoadFromText(list,"Datos_Final_2_feb_2020_TN.csv");
            printf("\nDatos Cargados ...\n");
            break;
        case 2:
            if(ll_len(list))
            {
                if(flag==0){
                    libro_imprimirListaLibros(list,flag);
                }
                else{
                    libro_imprimirListaLibros(list,flag);
                }
            }
            break;
        case 3:
            if(ll_len(list))
                {
                    /*ll_map(list, bicicleta_velocidadPromedio);
                    flag++;
                    printf("\nVelocidad Promedio Agregada...\n");

                    --------------------------------------------

                    ll_sort(list,libro_sortPorAutor,1);
                    */
                }
                else
                    printf("\nEl archivo aun no ha sido cargado.\n");
                break;
        case 4:/*
            if(ll_len(list))
            {
                do{
                    opcion2 = menu_Principal("\n1.BMX"
                                              "\n2.PLAYERA"
                                              "\n3.MTB"
                                              "\n4.PASEO\n"
                                            "\nElegir opcion: ");

                    switch(opcion2)
                    {
                    case 1:
                        listaPorTipo = ll_filter(list,bicicleta_filterBMX);
                        break;
                    case 2:
                        listaPorTipo = ll_filter(list,bicicleta_filterPLAYERA);
                        break;
                    case 3:
                        listaPorTipo = ll_filter(list,bicicleta_filterMTB);
                        break;
                    case 4:
                        listaPorTipo = ll_filter(list,bicicleta_filterPASEO);
                        break;
                    }
                }while(opcion2<=1 && opcion2 >=4);

                parser_SaveFromText(listaPorTipo,"mapeado.csv");
            }*/
                break;
        case 5:
            if(ll_len(list))
            {
                //bicicleta_sortBicicletas(list);
                //bicicleta_sortByTipo(list);
                //bicicleta_imprimirListaBicicletas(list);

                //ll_sort(list, bicicleta_sortByTipo, 1);

            }
            break;


        }
    }while(opcion != 5);




    return 0;
}
